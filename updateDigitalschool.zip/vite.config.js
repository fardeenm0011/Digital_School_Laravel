import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css', 
                'resources/css/Base.css',
                'resources/css/Common.css',
                'resources/css/Edit_profile.css',
                'resources/css/Home_empty.css',
                'resources/css/Home.css',
                'resources/css/Leftmenu.css',
                'resources/css/Navbar.css',
                'resources/css/Promotion.css',
                'resources/css/RemoveStudentList.css',
                'resources/css/Settings.css',
                'resources/js/app.js',
            ],
            refresh: true,
        }),
    ],
});
