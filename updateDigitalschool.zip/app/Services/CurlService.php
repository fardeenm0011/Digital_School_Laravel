<?php

namespace App\Services;

class CurlService
{
    public static function getCurlResult($url, $httpMethod = 'POST', $headers = [], $params = [], $jsonBodyPost = false)
    {
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        switch ($httpMethod) {
            case 'POST':
                curl_setopt($curl, CURLOPT_POST, true);
                break;
            case 'PUT':
                $headers['X-HTTP-Method-Override'] = 'PUT';
                break;
            case 'PATCH':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PATCH');
                break;
            case 'GET':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
                break;
        }

        if ($jsonBodyPost) {
            $params = json_encode($params);
        }

        curl_setopt($curl, CURLOPT_POSTFIELDS, $params);

        if (count($headers) > 0) {
            $headerArray = [];
            foreach ($headers as $key => $val) {
                $headerArray[] = $key.':'.$val;
            }
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headerArray);
        }

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $html = curl_exec($curl);
        $error = curl_errno($curl);
        $info = curl_getinfo($curl);

        if (! $html) {

            // Handle errors here
            if ($error) {
                // Log errors
            }
            curl_close($curl);

            return false;
        }

        curl_close($curl);

        return $html;
    }
}
