<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class AuthenticateUserService
{
    public static function authenticateUser($userKey)
    {

        //  $userObj = json_decode(Common::Common_AES_Decrypt($userKey, Yii::$app->params['externalApps']['EBOOK4']['hawkKey']), true);

        $url = config('iam.host.url').str_replace('{SSOToken}', $userKey, config('iam.verify_ssotoken.url'));

        // echo $url;
        // exit;
        $headers = [
            'PearsonExtSSOSession' => $userKey,
            'Content-Type' => 'application/json',
            'Accept-API-Version' => 'resource=2.0',
            'Cookie' => 'routingRegion=AP',
        ];

        $response = Http::withHeaders($headers)->post($url);

        $resultIAM = $response->json();

        return $resultIAM;

        if ($resultIAM['username'] != '' && strtolower($resultIAM['username']) == strtolower($args['userName'])) {
            return 'success';
        } else {
            \Log::debug('[Login] IAM authentication failed on user login, returning username: '.serialize($resultIAM));

            // echo "[Login] IAM authentication failed on user login, returning username: " . $resultIAM['username'];
            return null;
        }
    }
}
