<?php

namespace App\Services;

use App\Services\CurlService as CurlService;

class Common
{
    public static function Common_AES_Decrypt($data, $key = '', $method = 'AES-256-CBC')
    {
        $data = base64_decode($data);
        //$ivSize = openssl_cipher_iv_length($method);
        //$iv = substr($data, 0, $ivSize);
        $data = @openssl_decrypt(/*substr($data, $ivSize)*/ $data, $method, $key, OPENSSL_RAW_DATA/*, $iv*/);

        return $data;
    }

    public static function determineRoleFromLeapValue($RoleId)
    {
        switch ($RoleId) {
            case '1':
                return 'S';
                break;
            case '2':
            case '9':
                return 'T';
                break;
            default:
                return 'S';
                break;
        }
    }

    public static function checkLeapSchoolInfoAndRole($username)
    {
        $url = config('iam.leap.Host.url').str_replace(['${username}'], [strtolower($username)], config('iam.leap.getSchool.getYearInfo'));
        $CURLResult = CurlService::getCURLResult($url, 'POST');
        if ($CURLResult !== false) {
            //$leapSchoolList = @json_decode(@json_encode(simplexml_load_string($CURLResult,"SimpleXMLElement",LIBXML_NOCDATA)),1);
            $leapSchoolList = @json_decode(@json_encode(simplexml_load_string($CURLResult, 'SimpleXMLElement', LIBXML_NOCDATA)), 1);
            //var_dump($leapSchoolList);
            if (count(array_keys($leapSchoolList['Profile']['Role'])) > 0 && ! isset($leapSchoolList['Profile']['Role'][0])) {
                $leapSchoolList['Profile']['Role'] = [$leapSchoolList['Profile']['Role']];
            }
            foreach ($leapSchoolList['Profile']['Role'] as $role) {
                $roleId = $role['RoleID'];
                if (count(array_keys($role['Year'])) > 0 && ! isset($role['Year'][0])) {
                    $role['Year'] = [$role['Year']];
                }
                foreach ($role['Year'] as $year) {
                    if (is_array($year['School']) and ! isset($year['School']['SchoolCode'])) {
                        foreach ($year['School'] as $school) {
                            if ($school['SchoolCode'] != '') {
                                $yearSchoolInfo[$year['SchoolYear']] = ['SchoolCode' => (is_array($school['SchoolCode'])) ? '123' : $school['SchoolCode'], 'Role' => Common::determineRoleFromLeapValue($roleId)];
                            }
                        }
                    } else {
                        $yearSchoolInfo[$year['SchoolYear']] = ['SchoolCode' => (is_array($year['School']['SchoolCode'])) ? '123' : $year['School']['SchoolCode'], 'Role' => Common::determineRoleFromLeapValue($roleId)];
                    }
                }
            }
            ksort($yearSchoolInfo, SORT_STRING);

            //var_dump($yearSchoolInfo);
            return array_pop($yearSchoolInfo);
        } else {
            return false;
        }
    }

    public static function checkAndCreateUserLoginSession($username, $platform = '', $ssoToken = '', $iesId = '', $iesToken = '')
    {

        $url = config('iam.leap.Host.url').str_replace('${username}', $username, config('iam.leap.getProfile.getSimple'));

        $leapUser = @json_decode(@json_encode(simplexml_load_string(CurlService::getCURLResult($url, 'POST'), 'SimpleXMLElement', LIBXML_NOCDATA)), 1);

        if ($leapUser['Profile']['LoginID'] != '') {
            return $leapUser['Profile']['LoginID'];
            //$schoolCodeAndRole = Common::checkLeapSchoolInfoAndRole($username);

            // print_r($leapUser);
            // echo 'coming';
            // echo '<br>';
            // print_r($schoolCodeAndRole);

        }

        return '';
    }
}
