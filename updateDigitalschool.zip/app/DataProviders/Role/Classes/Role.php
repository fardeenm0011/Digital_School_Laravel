<?php

namespace App\DataProviders\Role\Classes;

class Role
{
    public function __construct(
        public int $roleId,
        public string $roleName
    ) {
    }
}
