<?php

namespace App\DataProviders\Role;

use Illuminate\Support\Collection;

interface RoleInterface
{
    public function getRoles(): Collection;
}
