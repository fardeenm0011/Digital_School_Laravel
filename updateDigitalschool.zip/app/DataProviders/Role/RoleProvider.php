<?php

namespace App\DataProviders\Role;

use App\DataProviders\Role\Classes\Role;
use App\Utils\BuildUrl;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class RoleProvider implements RoleInterface
{
    public function getRoles(): Collection
    {
        $queryString = ['method' => 'getProfile', 'asMethod' => 'getRole'];
        $url = BuildUrl::build_external_url($queryString);
        // echo $url;
        // exit;
        //$url = config('external-api.base_url');
        //$url .= '?method=getProfile&asMethod=getRole&loginId=mandy.chau@pearson.com&output=json';

        return $this->doRequest($url);
    }

    public function doRequest(string $url): Collection
    {
        try {

            $response = Http::get($url);
            if (! $response->successful()) {
                return Collection::make();
            }

            $data = $response->json();
            // echo '<pre>';
            // print_r($data);
            // exit;
            $rolesArr = [];

            if (isset($data['ACSMessage']['Profile']['Roles']['Role'])) {
                $rolsLoc = $data['ACSMessage']['Profile']['Roles']['Role'];

                // Check if Year is an array or a single School entry
                if (isset($rolsLoc[0])) {
                    foreach ($rolsLoc as $roleVal) {
                        $roleInfo = ['Name' => $roleVal['Name'], 'RoleID' => $roleVal['RoleID']];
                        $rolesArr[] = $roleInfo;
                    }
                } else {
                    $roleInfo = ['Name' => $rolsLoc['Name'], 'RoleID' => $rolsLoc['RoleID']];
                    $rolesArr[] = $roleInfo;
                }
            }

            return collect($rolesArr)
                ->map(function ($role) {
                    return new Role(
                        roleId: $role['RoleID'],
                        roleName : $role['Name']
                    );
                });
        } catch (Exception $e) {
            echo $e->getMessage();
            Log::error($e->getMessage());
            Log::error($e->getTraceAsString());

            return Collection::make();
        }
    }
}
