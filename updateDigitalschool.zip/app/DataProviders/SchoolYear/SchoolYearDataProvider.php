<?php

namespace App\DataProviders\SchoolYear;

use App\DataProviders\SchoolYear\Classes\SchoolYear;
use App\Utils\BuildUrl;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SchoolYearDataProvider implements SchoolYearInterface
{
    public function getSchoolyears(): Collection
    {
        $queryString = ['method' => 'getProfile',
            'asMethod' => 'getYearInfo'];
        $url = BuildUrl::build_external_url($queryString);
        //$url = config('external-api.base_url');
        //$url .= '?method=getProfile&asMethod=getYearInfo&loginId=mandy.chau@pearson.com&output=json';

        return $this->doRequest($url);
    }

    public function doRequest(string $url): Collection
    {
        try {

            $response = Http::get($url);
            if (! $response->successful()) {
                return Collection::make();
            }

            $data = $response->json();

            $schoolYears = [];

            if (isset($data['ACSMessage']['Profile']['Role']['Year'])) {
                $years = $data['ACSMessage']['Profile']['Role']['Year'];

                // Check if Year is an array or a single School entry
                if (isset($years[0])) {
                    foreach ($years as $year) {
                        $schoolYears[] = $year['SchoolYear'];
                    }
                } else {
                    $schoolYears[] = $years['SchoolYear'];
                }
            }

            return collect($schoolYears)
                ->map(function ($schoolYearObj) {
                    return new SchoolYear(
                        schoolYear: $schoolYearObj
                    );
                });

        } catch (Exception $e) {
            echo $e->getMessage();
            Log::error($e->getMessage());
            Log::error($e->getTraceAsString());

            return Collection::make();
        }
    }
}
