<?php

namespace App\DataProviders\SchoolYear\Classes;

class SchoolYear
{
    public function __construct(
        public string $schoolYear
    ) {
    }
}