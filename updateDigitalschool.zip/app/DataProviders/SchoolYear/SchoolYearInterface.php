<?php

namespace App\DataProviders\SchoolYear;

use Illuminate\Support\Collection;

interface SchoolYearInterface
{
    public function getSchoolYears(): Collection;
}
