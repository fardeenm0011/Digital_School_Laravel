<?php

namespace App\Helpers\Leap;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use stdClass;

class LeapApiHelper
{
    private $args;

    private $url;

    public function __construct($args = [])
    {

        $args['output'] = 'json';
        $this->args = $args;
    }

    public function getUri()
    {
        $leapUrl = config('leap.leap_url');

        return $leapUrl . '/acs-web/App/ACSGateway.do?' . http_build_query($this->args);
    }

    public function get($args = [])
    {
        $leapUrl = config('leap.leap_url');
        $res = Http::withQueryParameters($this->args + $args)->get($leapUrl . '/acs-web/App/ACSGateway.do')->body();

        return json_decode($res, true)['ACSMessage'];
    }

    public static function call($args = [])
    {
        $leapUrl = config('leap.leap_url');
        $args['output'] = 'json';
        $timeStart = microtime(true);
        Log::info('api call start');
        // $res = Http::withQueryParameters($args)->get($leapUrl . '/acs-web/App/ACSGateway.do')->body();
        $res = "string";
        $diff = microtime(true) - $timeStart;
        $sec = intval($diff);
        $micro = $diff - $sec;

        Log::info('Finished in: ' . round($micro * 1000, 4) . ' ms');

        // return json_decode($res, true)['ACSMessage'];
        $decodedRes = json_decode($res, true);
        $acsMessage = $decodedRes['ACSMessage'] ?? null;
        if (!isset($acsMessage)) {
            // Handle the case where 'ACSMessage' key is missing or null
            // You can log an error or return an appropriate response
            return null;
        }

        return $acsMessage;
    }

    public static function submitData($submitURL, $formData)
    {
        $leapUrl = config('leap.leap_url');
        $args['output'] = 'json';
        $timeStart = microtime(true);
        Log::info('api call start');
        $response = Http::post($leapUrl . '/' . $submitURL, $formData);
        $res = Http::withQueryParameters($args)->get($leapUrl . '/acs-web/App/ACSGateway.do')->body();
        $diff = microtime(true) - $timeStart;
        $sec = intval($diff);
        $micro = $diff - $sec;

        Log::info('Finished in: ' . round($micro * 1000, 4) . ' ms');

        return json_decode($res, true)['ACSMessage'];
    }

    public static function formatArrayField(&$data, $keyPath)
    {
        $curr = &$data;
        foreach ($keyPath as $value) {
            if (!isset($curr[$value])) {
                return;
            }
            $curr = &$curr[$value];
        }

        $values = count(array_keys($curr)) > 0 && !isset($curr[0]) ?
            [$curr] :
            $curr;

        $curr = $values;
    }
}
