<?php

namespace App\Utils;

class BuildUrl
{
    public static function build_external_url(array $query = [], ?string $path = null): string
    {
        $url = config('external-api.base_url');
        //$queryDefaults = ['loginId' => 'mandy.chau@pearson.com', 'output' => 'json'];
        $queryDefaults = ['loginId' => \Session::get('LoginID'), 'output' => 'json'];
        $queryString = array_merge($query, $queryDefaults);
        $urlPath = ($path === null ? config('external-api.endpoint_path') : $path);

        if ($urlPath !== null) {
            $url .= '/'.ltrim($urlPath, '/');
        }
        if (! empty($queryString)) {
            $url .= '?'.http_build_query($queryString);
        }

        return $url;
    }
}
