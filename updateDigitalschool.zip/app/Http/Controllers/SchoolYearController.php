<?php

namespace App\Http\Controllers;

use App\DataProviders\SchoolYear\SchoolYearDataProvider;

class SchoolYearController extends Controller
{
    public function __construct(protected SchoolYearDataProvider $schoolYearDataProvider)
    {

    }

    public function get()
    {

        return $this->schoolYearDataProvider->getSchoolyears();
    }
}
