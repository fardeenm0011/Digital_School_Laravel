<?php

namespace App\Http\Controllers;

use App\Helpers\Leap\LeapApiHelper;

class TestController extends Controller
{
    public function __construct()
    {

    }

    public function changePassword()
    {
        $formData = ['currentPwd' => 'sdadasda',
            'newPwd' => 'asdasda',
            'reTypePwd' => 'sdasdas',
            'submit' => '提交',
            'x' => 52,
            'y' => 14];
        $response = LeapApiHelper::submitData('acs-web/Teacher/changePassword.do', $formData);
        print_r($response);
        exit;
    }

    public function get()
    {
        $applicationDataResponse = LeapApiHelper::call([
            'method' => 'getApplicationIcon',
            'asMethod' => 'getByUser',
            'loginId' => 'tp12519191',
            'roleId' => 2,
            'schoolYearId' => 19,
        ]);

        $applications = [
            1 => [],
            2 => [],
            3 => [],
            4 => [],
            5 => [],
        ];

        foreach ($applicationDataResponse['Applications']['Application'] as $application) {
            $applications[$application['Type']][] = $application;
        }

        return $applications;
    }
}
