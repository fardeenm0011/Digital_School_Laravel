<?php

namespace App\Http\Controllers;

use App\DataProviders\Role\RoleProvider;
use App\DataProviders\SchoolYear\SchoolYearDataProvider;
use App\Helpers\Leap\LeapApiHelper;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{

    private function crossRoleSchoolYearDataQuery()
    {

        $loginId = Session::get('LoginID');

        $roleInfoResponse = LeapApiHelper::call([
            'method' => 'getProfile',
            'asMethod' => 'getRole',
            'loginId' => $loginId
        ]);

        $schoolYearInfoResponse = LeapApiHelper::call([
            'method' => 'getUsers',
            'asMethod' => 'getSchoolYearInfo',
            'loginId' => $loginId
        ]);

        $yearInfoResponse = LeapApiHelper::call([
            'method' => 'getProfile',
            'asMethod' => 'getYearInfo',
            'loginId' => $loginId
        ]);


        LeapApiHelper::formatArrayField($roleInfoResponse, ['Profile', 'Roles', 'Role']);

        $schoolYearMapping = [];

        echo ($schoolYearInfoResponse);
        exit(0);

        for ($i = 0; $i < count($schoolYearInfoResponse['SchoolYears']['SchoolYearID']); $i++) {
            $schoolYearMapping[$schoolYearInfoResponse['SchoolYears']['SchoolYearID'][$i]] = $schoolYearInfoResponse['SchoolYears']['SchoolYearName'][$i];
        }
        krsort($schoolYearMapping);

        $schoolYearInfoResponse['SchoolYears'] = $schoolYearMapping;

        LeapApiHelper::formatArrayField($yearInfoResponse, ['Profile', 'Role']);
        foreach ($yearInfoResponse['Profile']['Role'] as &$role) {
            LeapApiHelper::formatArrayField($role, ['Year']);
            foreach ($role['Year'] as &$year) {
                LeapApiHelper::formatArrayField($year, ['School']);
            }
        }

        $crossRoleSchoolYearInfo = [];

        foreach ($roleInfoResponse['Profile']['Roles']['Role'] as $r) {
            $roleId = $r['RoleID'];
            $roleName = $r['Name'];
            $schoolYears = [];

            foreach ($yearInfoResponse['Profile']['Role'] as $yearInfoRole) {
                if ($yearInfoRole['RoleID'] == $roleId) {
                    foreach ($yearInfoRole['Year'] as $y) {
                        foreach ($schoolYearInfoResponse['SchoolYears'] as $schoolYearId => $schoolYearName) {
                            if ($y['SchoolYear'] == $schoolYearName) {
                                foreach ($y['School'] as $key => $s) {
                                    if ($s['SchoolTypeId'] == 0 || $s['SchoolName'] == "" || $s['SchoolCode'] == "") {
                                        unset($y['School'][$key]);
                                    }
                                }
                                $y['School'] = array_values($y['School']);
                                $schoolYears[$schoolYearId] = $y;
                            }
                        }
                    }
                }
            }

            $crossRoleSchoolYearInfo[$roleId] = [
                'name' => $roleName,
                'schoolYears' => $schoolYears,
            ];
        }

        return $crossRoleSchoolYearInfo;
    }

    private function applicationDataQuery($roleId, $schoolYearId)
    {
        $loginId = Session::get('LoginID');

        $applicationDataResponse = LeapApiHelper::call([
            'method' => 'getApplicationIcon',
            'asMethod' => 'getByUser',
            'loginId' => $loginId,
            'roleId' => $roleId,
            'schoolYearId' => $schoolYearId
        ]);

        $applications = [
            "common" => [],
            "oac" => [],
            "platform" => [],
            "hidden" => [],
            "ebook" => []
        ];

        $applicationIdMapper = [
            1 => 'common',
            2 => 'oac',
            3 => 'platform',
            4 => 'hidden',
            5 => 'ebook'
        ];

        foreach ($applicationDataResponse["Applications"]["Application"] as $application) {
            $applications[$applicationIdMapper[$application['Type']]][] = $application;
        }

        return $applications;
    }

    public function checksession()
    {
        Session::put('LoginID', 'tp12519191');
        if (Session::has('LoginID')) {
            $crossRoleSchoolYearInfo = $this->crossRoleSchoolYearDataQuery();
            $selectedRoleId = array_key_first($crossRoleSchoolYearInfo);
            $selectSchoolYearId = array_key_first($crossRoleSchoolYearInfo[$selectedRoleId]['schoolYears']);

            $applicationsInfo = $this->applicationDataQuery($selectedRoleId, $selectSchoolYearId);

            return view('home', compact('crossRoleSchoolYearInfo', 'selectedRoleId', 'selectSchoolYearId', 'applicationsInfo'));
        } else {
            return redirect()->route('ssologin');
        }
    }

    public function showApplications()
    {
        $roleId = request()->get('roleId');
        $schoolYearId = request()->get('schoolYearId');
        $applicationsInfo = $this->applicationDataQuery($roleId, $schoolYearId);
        return response()->json($applicationsInfo);
        // return [
        //     'roleId' => $roleId,
        //     'schoolYearId' => $schoolYearId
        // ];
    }

    public function index()
    {
        // $schooYears = $this->schoolYearDataProvider->getSchoolyears();
        // $roles = $this->roleProvider->getRoles();
        // echo '<pre>';
        // print_r($schooYears);
        // print_r($roles);
    }
}
