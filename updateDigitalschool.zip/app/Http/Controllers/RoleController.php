<?php

namespace App\Http\Controllers;

use App\DataProviders\Role\RoleProvider;

class RoleController extends Controller
{
    public function __construct(protected RoleProvider $roleProvider)
    {

    }

    public function get()
    {

        return $this->roleProvider->getRoles();

    }
}
