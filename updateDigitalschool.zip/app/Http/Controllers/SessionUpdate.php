<?php

namespace App\Http\Controllers;

use App\Services\Common;
use Illuminate\Http\Request;

class SessionUpdate extends Controller
{
    //
    public function sessionUpdate(Request $request)
    {

        $userObj = json_decode(Common::Common_AES_Decrypt($request->get('userKey'), config('iam.externalApps.EBOOK4.hawkKey')), true);
        $validUser = Common::checkAndCreateUserLoginSession($userObj['username']);
        if ($validUser != '') {
            \Session::put('LoginID', $validUser);

            return redirect()->route('home');
        }
        echo 'Invalid User';
        exit;
    }
}
