<?php

namespace App\Http\Controllers;

class SSOLoginController extends Controller
{
    //
    public function ssoLogin()
    {
        $currentHost = 'https://'.$_SERVER['HTTP_HOST'].'/ssoverify';
        $IESurl = env('IESurl').'?lang='.env('IESlang').'&back_to=https://iesregister.beta4.ilongman.com/ieschecksession.php'.env('IESBACKurl').'%3Flang%3D'.env('IESlang2')
        .'%26back_to%3D'.$currentHost;

        return redirect($IESurl);
    }
}
