<?php

namespace App\Http\Controllers;

use App\Helpers\Leap\LeapApiHelper;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function changePassword(Request $request): JsonResponse
    {

        $currentPassword = $request->currentPwd;
        $newPassword = $request->newPwd;
        $formData = ['currentPwd' => $request->currentPwd,
            'newPwd' => $request->newPwd,
            'reTypePwd' => $request->reTypePwd,
            'submit' => '',
            'x' => 52,
            'y' => 14];
        $response = LeapApiHelper::submitData('acs-web/Teacher/changePassword.do', $formData);
        print_r($response);
        exit;
        //currentPwd=P%40ers0n1&newPwd=S151089s%40%40&reTypePwd=S151089s%40%40&submit=%E6%8F%90%E4%BA%A4&x=52&y=14

        return response()->json(['success' => 'Post created successfully.']);
    }
}
