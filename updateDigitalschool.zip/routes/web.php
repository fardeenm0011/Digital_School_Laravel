<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SchoolYearController;
use App\Http\Controllers\SessionUpdate;
use App\Http\Controllers\SSOLoginController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', function () {
    return view('home');
});

//Test Routes
Route::get('/test', [TestController::class, 'changePassword']);

//User Management Routes
Route::post('users', [UserController::class, 'changePassword'])->name('users.changepassword');

Route::get('/schoolyear', [SchoolYearController::class, 'get']);
Route::get('/roles', [RoleController::class, 'get']);
Route::redirect('/', '/home');

Route::get('/home', [HomeController::class, 'checksession'])->name('home');
Route::get('/applications', [HomeController::class, 'showApplications']);

Route::get('/ssologin', [SSOLoginController::class, 'ssoLogin'])->name('ssologin');

Route::get('/ssoverify', [SessionUpdate::class, 'SessionUpdate']);

Route::get('/topnav', function () {
    return view('top-nav');
});

// Route::get('/home/empty', function () {
//     return view('homeEmpty');
// });

Route::get('/setting', function () {
    return view('setting');
});

Route::get('/setting/editProfile', function () {
    return view('editProfile');
});

Route::get('/setting/promotion', function () {
    return view('promotion');
});

Route::get('/setting/addPin', function () {
    return view('addPin');
});

Route::get('/setting/changePassword', function () {
    return view('changePassword');
});

Route::get('/setting/emailOrMobile', function () {
    return view('emailOrMobile');
});

Route::get('/schoolManagement', function () {
    return view('schoolManagement');
});

Route::get('/schoolManagement/removeStudentFromClass', function () {
    return view('removeStudentFromClass');
});

Route::get('/schoolManagement/removeStudentFromClass_List', function () {
    return view('removeStudentFromClass_List');
});
