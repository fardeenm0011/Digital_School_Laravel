import './bootstrap';
import jQuery from 'jquery';
window.$ = jQuery;
