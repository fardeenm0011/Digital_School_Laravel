<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        
        <x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/Home_empty.css'"/>

        <x-head-style :linkTo="url('/home/empty')"/>

    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        <!-- Banner Image -->
        <x-body-banner/>
        
        <!-- Main Layout -->
        <div id="layoutSidenav">
            <!-- LeftMenu of Layout -->
            <x-home-empty-nav-menu/>

            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4">
                            
                            <x-main-card-top :title="'My Home'"/>

                            <div class="col">
                                <div class="row mt-4">
                                    
                                    <x-main-card-alert :alertMessage="'You have not finish the verification, go '"/>
                                    
                                    <x-main-card-alert :alertMessage="'You have not finish the setup of newsletter, go '"/>
                                </div>
                                <div class="row mb-5 home-empty-main">
                                    <div class="mt-2"><img src="{{ asset('img/homeempty.gif') }}"></div>
                                    <div class="mt-2">
                                        <p>You don't have a product yet, Please stay tuned for updates <br>
                                            from your school, or add your PIN now.
                                        </p>
                                    </div>
                                    <div class="mt-2"><button type="button" class="btn btn-text-download">Add PIN</button></div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
           
        </div>
        <x-footer />
    </body>
</html>
