<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/RemoveStudentList.css'"/>

        <x-head-style :linkTo="url('/schoolManagement')"/>

    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <x-side-nav-menu />

            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4 ">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 FYI-title">Remove student from class</h3>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="router-title"><a class="link-blue text-decoration-none" href="{{ url('/setting') }}">My Settings</a>
                                    <i class="fa-sharp fa-greater-than"></i>
                                    Remove student from class
                                </p>
                            </div>
                            <div class="row">
                                <form>
                                    <div class="card mb-4">
                                        <div class="card-body table-container " onload="onStuendtTableLoad()">
                                            <table id="studentListTable">
                                                <thead>
                                                    <tr>
                                                        <th class="bg-warning">1A (Before)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                            <table id="removedStudentListTable">
                                                <thead>
                                                    <tr>
                                                        <th class="bg-success">1A (After Removal)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row mb-4 mt-4 mr-1 ">
                                        <button type="submit" class="btn btn-save">Save Setting</button>
                                    </div>
                                </form>
                            </div>
                            
                        </div>
                    </main>
                </div>
            </div>
        </div>
        <x-footer />
        <script>
            var studentList = ["sp001234586", "sp001234587", "sp001234588", "sp001234589",
                                "sp001234590", "sp001234591", "sp001234592", "sp001234593",
                                "sp001234594", "sp001234595", "sp001234596", "sp001234597",
                                "sp001234598"];
            
            onload = function onStuendtTableLoad(){
                var insertColumn = '';
                var No = 1;
                studentList.forEach(student => {
                    insertColumn += "<tr><td>"+ No.toString() + "." + student + "</td></tr>";
                    No++;
                });
                var beforeTable = document.getElementById("studentListTable");
                var beforeTableBody = beforeTable.getElementsByTagName("tbody")[0];
                beforeTableBody.innerHTML = insertColumn;
                var afterTable = document.getElementById("removedStudentListTable");
                var afterTableBody = afterTable.getElementsByTagName("tbody")[0];
                afterTableBody.innerHTML = insertColumn;
            }

        </script>
    </body>
</html>
