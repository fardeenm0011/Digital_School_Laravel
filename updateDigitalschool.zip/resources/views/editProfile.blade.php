<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <<x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/Edit_profile.css'"/>

        <x-head-style :linkTo="url('/setting')"/>
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <x-side-nav-menu />

            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4 ">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 FYI-title">Edit my profile</h3>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="router-title"><a class="link-blue text-decoration-none" href="{{ url('/setting') }}">My Settings</a>
                                    <i class="fa-sharp fa-greater-than"></i>
                                    Edit my profile
                                </p>
                            </div>
                            <div class="row mt-3">
                                <form>
                                    <div class="row">
                                        <div class="mb-5 col-xl-4" >
                                            <i class="fa-solid fa-circle-user" id="profile-icon" ></i>
                                            <button class="btn profile-change">Change</button>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <label>Username</label>
                                            <p id="username">chris_wong_123</p>
                                        </div>
                                    </div>
                                    <div class="row divider">
                                        <div class="mb-3 col-xl-4">
                                            <label for="newUsername" class="form-label">Type new username</label>
                                            <input type="password" class="form-control mb-5" id="newUsername">
                                        </div>
                                    </div>
                                    <div class="row mb-4 mt-4 mr-1 ">
                                        <button type="submit" class="btn btn-save">Save Setting</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        
        <x-footer />
    </body>
</html>
