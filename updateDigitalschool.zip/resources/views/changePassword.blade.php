<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/Settings.css'"/>
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        <x-head-style :linkTo="url('/setting')"/>
        
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <x-side-nav-menu />
            
            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4 ">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 FYI-title">Change Password</h3>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="router-title"><a class="link-blue text-decoration-none" href="{{ url('/setting') }}">My Settings</a>
                                    <i class="fa-sharp fa-greater-than"></i>
                                    Change Password
                                </p>
                            </div>
                            <div class="row mt-2">
                                <form name="changepassword_formAjax" method="post" id="changepassword_formAjax" action="{{ route('users.changepassword') }}">
                                @csrf
                                    <div class="alert alert-danger print-error-msg" style="display:none">
                                    <ul></ul>
                                    </div>
                                    <div class="row">
                                        <div class="mb-3 col-xl-4">
                                            <label for="existingPassword" class="form-label">Existing Password</label>
                                            <input type="password" class="form-control" name="currentPwd" id="changePasswordForm_currentPwd" required>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="mb-3 col-xl-4">
                                            <label for="newPassword" class="form-label">New Password</label>
                                            <input type="password" class="form-control" name="newPwd" id="newPwd" required>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="mb-3 col-xl-4">
                                            <label for="retypePassword" class="form-label">Re-types the new password</label>
                                            <input type="password" class="form-control" name="reTypePwd" id="changePasswordForm_reTypePwd" required>
                                        </div>
                                    </div>
                                    <div class="divider mt-4"></div>
                                    <div class="row mb-4">
                                        <button type="submit" class="btn btn-save">Save Setting</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        
        <x-footer />
        <script type="module">
               $(document).ready(function() {
                alert("coming")
                $('#changepassword_formAjax').submit(function(e) {
        e.preventDefault();
         
        var url = $(this).attr("action");
        let formData = new FormData(this);

        if($('#newPwd').val() != $('#reTypePwd').val()){
        $('#changepassword_formAjax').find(".print-error-msg").find("ul").html('');
        $('#changepassword_formAjax').find(".print-error-msg").css('display','block');
        $('#changepassword_formAjax').find(".print-error-msg").find("ul").append('<li>Password and Retype Password Doesnot Match</li>');
        return false;
        }
    
        $.ajax({
                type:'POST',
                url: url,
                data: formData,
                contentType: false,
                processData: false,
                success: (response) => {
                    info('Form submitted successfully');                            
                    $('#postModal').hide();       
                },
                error: function(response){
                    $('#ajax-form').find(".print-error-msg").find("ul").html('');
                    $('#ajax-form').find(".print-error-msg").css('display','block');
                    $.each( response.responseJSON.errors, function( key, value ) {
                        $('#changepassword_formAjax').find(".print-error-msg").find("ul").append('<li>'+value+'</li>');
                    });
                }
           });
        
    });

               });

</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"applicationID":"1087583384","applicationTime":13,"beacon":"bam.nr-data.net","queueTime":0,"licenseKey":"7393d53ab5","transactionName":"ZlUHZkACVkcAVERZDl8fNkZAFkxHIFREWQ5fHwZaUw1fUTFWQ0MWXkIB","agent":"","errorBeacon":"bam.nr-data.net"}</script>

    </body>
</html>
