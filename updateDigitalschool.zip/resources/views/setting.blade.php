<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/Settings.css'"/>

        <x-head-style :linkTo="url('/setting')"/>
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <x-side-nav-menu />

            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 order-1 FYI-title">My Settings</h3>
                            </div>
                            <div>
                                <div class="row mt-4">
                                    <label class="divider"><i class="fa-solid fa-user"></i> My Profile </label>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/setting/editProfile') }}">
                                            <div class="card  text-black setting-cards" id="setting_profile_edit">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/manage_accounts.png') }}" />
                                                </div>
                                            </div>
                                            <p>Edit My Profile</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/setting/promotion') }}">
                                            <div class="card text-black setting-cards" id="setting_profile_promotion">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/email.png') }}"  />
                                                </div>
                                            </div>
                                            <p>Promotion and Newsletter</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/setting/schaddPin') }}">
                                            <div class="card text-black setting-cards" id="setting_profile_addin">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/qr_code.png') }}" />
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Add Pin</p>
                                                <p class="order-2"><a target="_blank" href={{config('Settings.Add_Pin'))}}><i class="fa-solid fa-up-right-from-square"></i></a></p>
                                            </div>
                                        </a>
                                    </div>
                                </div>

                                <div class="row my-4">
                                    <label class="divider"><i class="fa-solid fa-shield-halved"></i> Security </label>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/setting/changePassword') }}">
                                            <div class="card text-black setting-cards" id="setting_security_password">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/password.png') }}" />
                                                </div>
                                            </div>
                                            <p>Change Password</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/setting/emailOrMobile') }}">
                                            <div class="card text-black setting-cards" id="setting_security_email">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/verified_user.png') }}" />
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Email or Mobile Verification</p>
                                                <p class="order-2"><a><i class="fa-solid fa-up-right-from-square"></i></a></p>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        
        <x-footer />
    </body>
</html>
