<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>

        <x-head-base />

        <x-head-vite :importCssPath="'resources/css/Home.css'"/>

        <x-head-style :linkTo="url('/')"/>
        <meta name="app-url" content="{{ url('/') }}">
        <meta name="icon-base-url" content="{{ config("leap.application.icon.basePath") }}">

    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />

        <!-- Banner Image -->
        <x-body-banner/>

        <!-- Main Layout -->
        <div id="layoutSidenav">

            <x-side-nav-menu />

            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4">

                            <x-main-card-top :title="'My Home'"/>

                            <div class="col">
                                <div class="row mt-4">

                                    <x-main-card-alert :alertMessage="'You have not finish the setup of newsletter, go '"/>

                                </div>
                                <div class="row mt-2">
                                    <div class="col-xl-3 col-md-6">
                                        <p class="mt-3 mb-0">Identity</p>
                                        <div class="card mb-4 border-none">
                                            <select class="form-select" id="role_option">

                                                @foreach($crossRoleSchoolYearInfo as $roleId => $role)
                                                <option value="{{$roleId}}"
                                                 {{ $selectedRoleId == $roleId ? 'selected' : ''}}
                                                >
                                                    {{$role['name']}}
                                                </option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <p class="mt-3 mb-0">School Year</p>
                                        <div class="card mb-4 border-none">
                                            <select class="form-select" id="school_year_option">

                                                @foreach($crossRoleSchoolYearInfo[$selectedRoleId]['schoolYears'] as $schoolYearId => $schoolYear)
                                                <option value="{{$schoolYearId}}"
                                                {{ $selectSchoolYearId == $schoolYearId ? 'selected' : ''}}
                                                >
                                                    {{$schoolYear['SchoolYear']}}
                                                </option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="platform-section">
                                    <label class="divider sub-title"><i class="fa-solid fa-rectangle-list mr-2" ></i>Platform</label>
                                    <div class="row application-content">
                                        @foreach ($applicationsInfo['platform'] as $application)
                                        <div class="col-4 application-wrapper">
                                            <a href={{ $application["TeacherURL"] }}>
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src={{ config("leap.application.icon.basePath")."/".$application["TeacherIcon"] }} /></div>
                                                    <div class="col-xl-8"><span>{{ $application["Name"] }}</span></div>
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="row mb-5" id="common-section">
                                    <label class="divider sub-title"><i class="fa-regular fa-file-lines mr-2"></i>Teacher Resource</label>
                                    <div class="row application-content">
                                        @foreach ($applicationsInfo['common'] as $application)
                                        <div class="col-4 application-wrapper">
                                            <a href={{ $application["TeacherURL"] }}>
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src={{ config("leap.application.icon.basePath")."/".$application["TeacherIcon"] }} /></div>
                                                    <div class="col-xl-8"><span>{{ $application["Name"] }}</span></div>
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="row mb-5" id="ebook-section">
                                    <label class="divider sub-title"><i class="fa-regular fa-file-lines mr-2"></i>EBook</label>
                                    <div class="row application-content">
                                        @foreach ($applicationsInfo['ebook'] as $application)
                                        <div class="col-4 application-wrapper">
                                            <a href={{ $application["TeacherURL"] }}>
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src={{ config("leap.application.icon.basePath")."/".$application["TeacherIcon"] }} /></div>
                                                    <div class="col-xl-8"><span>{{ $application["Name"] }}</span></div>
                                                </div>
                                            </a>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>

        </div>
        <x-footer />

        <script type="module">
            $(document).ready(function() {
                $('#role_option').on('change', function(){
                    getApplications();
                });

                $('#school_year_option').on('change', function(){
                    getApplications();
                });

                function applicationUITemplate(application){
                    let iconBaseUrl = $('meta[name=icon-base-url]').attr("content");
                    let html = "";
                    html += `<div class="col-4 application-wrapper">`;
                    html += `<a href="${application["TeacherURL"]}">`;
                    html += `<div class="row">`;
                    html += `<div class="col-xl-4 platform-image"><img src="${iconBaseUrl}/${application["TeacherIcon"]}" /></div>`;
                    html += `<div class="col-xl-8"><span>${ application["Name"] }</span></div></div></a></div>`;

                    return html;
                }

                function getApplications(){
                    let roleId = $('#role_option > option:selected').val();
                    let schoolYearId = $('#school_year_option > option:selected').val();
                    let url = $('meta[name=app-url]').attr("content") + "/applications?roleId="+roleId+"&schoolYearId="+schoolYearId;

                    $.ajax({
                        url: url,
                        type: "GET",
                        success: function(response) {
                            console.log(response);

                            $("#platform-section .application-content").empty();
                            $("#common-section .application-content").empty();
                            $("#ebook-section .application-content").empty();

                            response['platform'].forEach(application => {
                                $("#platform-section .application-content").append(applicationUITemplate(application));
                            });

                            response['common'].forEach(application => {
                                $("#common-section .application-content").append(applicationUITemplate(application));
                            });

                            response['ebook'].forEach(application => {
                                $("#ebook-section .application-content").append(applicationUITemplate(application));
                            });
                        },
                        error: function(response) {
                            console.log(response.responseJSON)
                        }
                    });
                }
            });
        </script>
    </body>
</html>
