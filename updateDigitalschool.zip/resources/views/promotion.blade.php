<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
    <x-head-base />
        
    <x-head-vite :importCssPath="'resources/css/Promotion.css'"/>

    <x-head-style :linkTo="url('/setting/promotion')"/>
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <x-home-empty-nav-menu/>
            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4 ">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 FYI-title">Promotion and Newsletter</h3>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="router-title"><a class="link-blue text-decoration-none" href="{{ url('/setting') }}">My Settings</a>
                                    <i class="fa-sharp fa-greater-than"></i>
                                    Promotion and Newsletter
                                </p>
                            </div>
                            <div class="row mt-3">
                                <form>
                                    <div class="row">
                                        <p class="mb-3">Person will launch various promotional activitied from time to time, ranging from teaching <br>
                                            techniques, sharing to learning materials discounts. Stay connected, stay inspired!
                                        </p>
                                    </div>
                                    <div class="row">
                                        <p class="mb-3">Please select the type you would like to receive from the list below</p>
                                    </div>
                                    <div class="row mt-3 d-block">
                                        <input type="checkbox" class="form-check-input mb-5" id="promotion_check1" checked>
                                        <label for="promotion_check1" class="checkbox-label">Keep me informed of product related information, discounts and promotional offers.</label>
                                    </div>
                                    <div class="row d-block">
                                        <input type="checkbox" class="form-check-input mb-2" id="promotion_check2">
                                        <label for="promotion_check2" class="checkbox-label">Parenting Information</label>
                                    </div>
                                    <div class="row d-block">
                                        <input type="checkbox" class="form-check-input mb-2" id="promotion_check3">
                                        <label for="promotion_check3" class="checkbox-label">Primary School</label>
                                    </div>
                                    <div class="row divider d-block">
                                        <input type="checkbox" class="form-check-input mb-5" id="promotion_check4">
                                        <label for="promotion_check4" class="checkbox-label">Secondary School</label>
                                    </div>
                                    <div class="row mb-4 mt-4 mr-1 ">
                                        <button type="submit" class="btn btn-save">Save Setting</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        
        <x-footer />
    </body>
</html>
