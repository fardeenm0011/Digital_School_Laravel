<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/Settings.css'"/>

        <x-head-style :linkTo="url('/schoolManagement')"/>
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            
            <!-- LeftMenu of Layout -->
            <x-side-nav-menu />
            
            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 order-1 FYI-title">School Management</h3>
                                <div class="mt-4 order-2">
                                    <button type="button" class="btn btn-dark btn-text-download">Contact Us</button>
                                </div>
                            </div>
                            <div>
                                <div class="row mt-4">
                                    <label class="divider"><i class="fa-solid fa-download"></i> Download Student Information </label>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/schoolManagement/removeStudentFromClass') }}">
                                            <div class="card text-black setting-cards" id="setting_profile_promotion">
                                                <div class="card-body setting-cards-body">
                                                    <i class="fa-regular fa-rectangle-list size-30"></i>
                                                </div>
                                            </div>
                                            <p>Download Student PINS</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/schoolManagement/removeStudentFromClass') }}">
                                            <div class="card text-black setting-cards" id="setting_profile_addin">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/qr_code.png') }}" />
                                                </div>
                                            </div>
                                            <p>Download Registered Student<br>Account List</p>
                                        </a>
                                    </div>
                                </div>
                                <div class="row my-4">
                                    <label class="divider"><i class="fa-solid fa-users"></i> Manage Class </label>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/schoolManagement/removeStudentFromClass') }}">
                                            <div class="card text-black setting-cards" id="setting_security_email">
                                                <div class="card-body setting-cards-body">
                                                    <i class="fa-solid fa-user-minus size-30"></i>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Remove student from class</p>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="{{ url('/schoolManagement/changePassword') }}">
                                            <div class="card text-black setting-cards" id="setting_security_password">
                                                <div class="card-body setting-cards-body">
                                                    <img src="{{ asset('img/icons/password.png') }}" />
                                                </div>
                                            </div>
                                            <p>Change password for student</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        <x-footer />
    </body>
</html>
