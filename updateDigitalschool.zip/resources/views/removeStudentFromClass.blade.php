<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <x-head-base />
        
        <x-head-vite :importCssPath="'resources/css/Promotion.css'"/>

        <x-head-style :linkTo="url('/schoolManagement')"/>
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <x-top-nav />
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <x-side-nav-menu />

            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4 ">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 FYI-title">Remove student from class</h3>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="router-title"><a class="link-blue text-decoration-none" href="{{ url('/setting') }}">My Settings</a>
                                    <i class="fa-sharp fa-greater-than"></i>
                                    Remove student from class
                                </p>
                            </div>
                            <div class="row">
                                <form>
                                    <div class="col-xl-3 col-md-6">
                                        <p class="mt-3 mb-1">Class</p>
                                        <div class="card mb-2">
                                            <select class="form-select" id="class_option" >
                                                <option selected value="IA">IA</option>
                                                <option value="IB">IB</option>
                                                <option value="IC">IC</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6 mt-4">
                                        <p class="mb-1">Login IO</p>
                                        <div class="card mb-2">
                                            <select class="form-select" id="loginIO">
                                                <option value="" disabled selected>--- Please Select ---</option>
                                                <option value="sp001234586">sp001234586</option>
                                                <option value="sp001234587">sp0012345687</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-check form-switch divider pt-4 pb-5">
                                        <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                                        <label class="form-check-label" for="flexSwitchCheckDefault">Auto adjust class name number for student in class</label>
                                    </div>
                                    <div class="row mb-4 mt-4 mr-1 ">
                                        <button type="submit" class="btn btn-save">Save Setting</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>

        <x-footer />
    </body>
</html>
