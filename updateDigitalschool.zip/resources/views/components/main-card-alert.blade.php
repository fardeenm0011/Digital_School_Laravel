@props(['alertMessage'])

<div class="info-panel mt-2">
    <p class="m-3">{{$alertMessage}}<a class="link-blue" href="#">setup now.</a><a class="link-blue link-setup-later" href="#">Setup Later</a></p>
</div>