<div>
    <!-- Live as if you were to die tomorrow. Learn as if you were to live forever. - Mahatma Gandhi -->
    <nav class="footer">
        <div class="container-fluid">
            <a class="footer_item" href="#"><span>Fixed bottom</span></a>
            <a class="footer_item" href="#"><span>Fixed bottom</span></a>
            <a class="footer_item" href="#"><span>Fixed bottom</span></a>
            <a class="footer_item" href="#"><span>Fixed bottom</span></a>
            <a class="footer_item" href="#"><span>Fixed bottom</span></a>
            <a class="footer_item" href="#"><span>Fixed bottom</span></a>
        </div>
    </nav>
</div>