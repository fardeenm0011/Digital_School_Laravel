<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-white" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="card mx-3 sidebar-card">
                <div class="nav p-3">
                    <a class="nav-link br-10 mb-3" href="{{ url('/home/empty') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-house"></i></div>
                        <label class="left-menu-text">My Home</label>
                    </a>
                    <a class="nav-link br-10 mb-5" href="{{ url('/setting') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div>
                        <label class="left-menu-text">My Settings</label>
                    </a>
                </div>
            </div>
        </div>
    </nav>
</div>