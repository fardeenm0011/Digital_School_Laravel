@props(['linkTo'])

<style>
    .nav-link:not([href="{{ $linkTo }}"]) {
        display: none;
    }
    .nav-link[href="{{ $linkTo }}"]{
        background-color: white;
        color: #007A9C;
    }
    .nav-link[href="{{ $linkTo }}"] .left-menu-text{
        color: #007A9C;
    }
</style>