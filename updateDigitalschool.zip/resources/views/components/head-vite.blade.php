@props(['importCssPath'])

@php


$styles = [
'resources/js/app.js',
'resources/css/Common.css',
'resources/css/Leftmenu.css',
'resources/css/Navbar.css',
$importCssPath
];

@endphp

@vite($styles)