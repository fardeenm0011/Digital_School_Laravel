@props(['title'])

<div class="d-flex justify-content-between align-items-center">
    <h3 class="mt-4 order-1 FYI-title"> {{$title}} </h3>
    <div class="mt-4 order-2">
        <button type="button" class="btn btn-dark btn-text-download">How to use</button>
        <button type="button" class="btn btn-dark btn-text-download">Download Apps</button>
    </div>
</div>