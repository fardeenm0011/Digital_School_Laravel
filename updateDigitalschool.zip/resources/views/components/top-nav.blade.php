<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
    <nav class="sb-topnav navbar navbar-white bg-white">
        <a class="navbar-brand ps-3" href="{{ url('/') }}">
            <img class="navbar-logo" src="{{ asset('img/logo.png') }}" alt="Logo">
        </a>
        <div class="dropdown">
            <span class="navbar-profile" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <h2><i class="fa-solid fa-circle-user"></i></h2>
            </span>

            <ul class="dropdown-menu end-right">
                <li><a class="dropdown-item" href="#">Hello, <?php echo 'chris_wong_123' ?></a></li>
                <li><a class="dropdown-item" href="#"><i class="fa-solid fa-language"></i>中文</a></li>
                <li><a class="dropdown-item" href="#"><i class="fa-solid fa-arrow-right-from-bracket"></i>Sign out</a></li>
            </ul>
        </div>
    </nav>
</div>