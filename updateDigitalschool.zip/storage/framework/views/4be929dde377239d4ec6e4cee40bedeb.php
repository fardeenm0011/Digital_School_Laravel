<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['linkTo']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['linkTo']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<style>
    .nav-link:not([href="<?php echo e($linkTo); ?>"]) {
        display: none;
    }
    .nav-link[href="<?php echo e($linkTo); ?>"]{
        background-color: white;
        color: #007A9C;
    }
    .nav-link[href="<?php echo e($linkTo); ?>"] .left-menu-text{
        color: #007A9C;
    }
</style><?php /**PATH C:\xampp\htdocs\my-pearson-digital-v2\resources\views/components/head-style.blade.php ENDPATH**/ ?>