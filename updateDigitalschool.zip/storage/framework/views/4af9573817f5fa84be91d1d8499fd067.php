<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php if (isset($component)) { $__componentOriginal9b26c56ae0f948ae51e873b8663e9f53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-base','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53)): ?>
<?php $attributes = $__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53; ?>
<?php unset($__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b26c56ae0f948ae51e873b8663e9f53)): ?>
<?php $component = $__componentOriginal9b26c56ae0f948ae51e873b8663e9f53; ?>
<?php unset($__componentOriginal9b26c56ae0f948ae51e873b8663e9f53); ?>
<?php endif; ?>
        
        <?php if (isset($component)) { $__componentOriginale483f3705a29c7628916796976d4b129 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale483f3705a29c7628916796976d4b129 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-vite','data' => ['importCssPath' => 'resources/css/Settings.css']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-vite'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['importCssPath' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('resources/css/Settings.css')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale483f3705a29c7628916796976d4b129)): ?>
<?php $attributes = $__attributesOriginale483f3705a29c7628916796976d4b129; ?>
<?php unset($__attributesOriginale483f3705a29c7628916796976d4b129); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale483f3705a29c7628916796976d4b129)): ?>
<?php $component = $__componentOriginale483f3705a29c7628916796976d4b129; ?>
<?php unset($__componentOriginale483f3705a29c7628916796976d4b129); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal0cbc308b3ff0276709ae76208f29eb48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0cbc308b3ff0276709ae76208f29eb48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-style','data' => ['linkTo' => url('/setting')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-style'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['linkTo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(url('/setting'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0cbc308b3ff0276709ae76208f29eb48)): ?>
<?php $attributes = $__attributesOriginal0cbc308b3ff0276709ae76208f29eb48; ?>
<?php unset($__attributesOriginal0cbc308b3ff0276709ae76208f29eb48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0cbc308b3ff0276709ae76208f29eb48)): ?>
<?php $component = $__componentOriginal0cbc308b3ff0276709ae76208f29eb48; ?>
<?php unset($__componentOriginal0cbc308b3ff0276709ae76208f29eb48); ?>
<?php endif; ?>
    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <?php if (isset($component)) { $__componentOriginal567aee8eba9946a4094af278d0455b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal567aee8eba9946a4094af278d0455b7e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.top-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('top-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal567aee8eba9946a4094af278d0455b7e)): ?>
<?php $attributes = $__attributesOriginal567aee8eba9946a4094af278d0455b7e; ?>
<?php unset($__attributesOriginal567aee8eba9946a4094af278d0455b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal567aee8eba9946a4094af278d0455b7e)): ?>
<?php $component = $__componentOriginal567aee8eba9946a4094af278d0455b7e; ?>
<?php unset($__componentOriginal567aee8eba9946a4094af278d0455b7e); ?>
<?php endif; ?>
        
        <!-- Main Layout -->
        <div id="layoutSidenav" class="layout">
            <!-- LeftMenu of Layout -->
            <?php if (isset($component)) { $__componentOriginald5b0d6cc9367610ffc331bacb8d5777a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-nav-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('side-nav-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a)): ?>
<?php $attributes = $__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a; ?>
<?php unset($__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5b0d6cc9367610ffc331bacb8d5777a)): ?>
<?php $component = $__componentOriginald5b0d6cc9367610ffc331bacb8d5777a; ?>
<?php unset($__componentOriginald5b0d6cc9367610ffc331bacb8d5777a); ?>
<?php endif; ?>

            <!-- Content of Layout -->
            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4">
                            <!-- Page Title -->
                            <div class="d-flex justify-content-between align-items-center">
                                <h3 class="mt-4 order-1 FYI-title">My Settings</h3>
                            </div>
                            <div>
                                <div class="row mt-4">
                                    <label class="divider"><i class="fa-solid fa-user"></i> My Profile </label>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="<?php echo e(url('/setting/editProfile')); ?>">
                                            <div class="card  text-black setting-cards" id="setting_profile_edit">
                                                <div class="card-body setting-cards-body">
                                                    <img src="<?php echo e(asset('img/icons/manage_accounts.png')); ?>" />
                                                </div>
                                            </div>
                                            <p>Edit My Profile</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="<?php echo e(url('/setting/promotion')); ?>">
                                            <div class="card text-black setting-cards" id="setting_profile_promotion">
                                                <div class="card-body setting-cards-body">
                                                    <img src="<?php echo e(asset('img/icons/email.png')); ?>"  />
                                                </div>
                                            </div>
                                            <p>Promotion and Newsletter</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="<?php echo e(url('/setting/schaddPin')); ?>">
                                            <div class="card text-black setting-cards" id="setting_profile_addin">
                                                <div class="card-body setting-cards-body">
                                                    <img src="<?php echo e(asset('img/icons/qr_code.png')); ?>" />
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Add Pin</p>
                                                <p class="order-2"><a><i class="fa-solid fa-up-right-from-square"></i></a></p>
                                            </div>
                                        </a>
                                    </div>
                                </div>

                                <div class="row my-4">
                                    <label class="divider"><i class="fa-solid fa-shield-halved"></i> Security </label>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="<?php echo e(url('/setting/changePassword')); ?>">
                                            <div class="card text-black setting-cards" id="setting_security_password">
                                                <div class="card-body setting-cards-body">
                                                    <img src="<?php echo e(asset('img/icons/password.png')); ?>" />
                                                </div>
                                            </div>
                                            <p>Change Password</p>
                                        </a>
                                    </div>
                                    <div class="col-xl-3">
                                        <a class="text-decoration-none" href="<?php echo e(url('/setting/emailOrMobile')); ?>">
                                            <div class="card text-black setting-cards" id="setting_security_email">
                                                <div class="card-body setting-cards-body">
                                                    <img src="<?php echo e(asset('img/icons/verified_user.png')); ?>" />
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Email or Mobile Verification</p>
                                                <p class="order-2"><a><i class="fa-solid fa-up-right-from-square"></i></a></p>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>
        
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\my-pearson-digital-v2\resources\views/setting.blade.php ENDPATH**/ ?>