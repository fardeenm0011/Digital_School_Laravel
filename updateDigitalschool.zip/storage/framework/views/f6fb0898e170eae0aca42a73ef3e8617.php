<div id="banner" style="background-image: url(<?php echo e(asset('img/home_background.png')); ?>)" class="d-flex justify-content-center position-relative banner-image">
    <div class="overlay-text">
        <p class="text-white fs-3 fw-light font-family-Inter  m-0 px-3 py-2">Welcome to English <br/></p>
        <p class="text-white fs-6 fw-normal font-family-Inter  m-0 px-3 py-2">Explore, discover, and grow together with our tailored resources. Let's make learning fun!<br/></p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\my-pearson-digital-v2\resources\views/components/body-banner.blade.php ENDPATH**/ ?>