<head>
    <?php if (isset($component)) { $__componentOriginal9b26c56ae0f948ae51e873b8663e9f53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-base','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53)): ?>
<?php $attributes = $__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53; ?>
<?php unset($__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b26c56ae0f948ae51e873b8663e9f53)): ?>
<?php $component = $__componentOriginal9b26c56ae0f948ae51e873b8663e9f53; ?>
<?php unset($__componentOriginal9b26c56ae0f948ae51e873b8663e9f53); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginale483f3705a29c7628916796976d4b129 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale483f3705a29c7628916796976d4b129 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-vite','data' => ['importCssPath' => 'resources/css/Base.css']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-vite'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['importCssPath' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('resources/css/Base.css')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale483f3705a29c7628916796976d4b129)): ?>
<?php $attributes = $__attributesOriginale483f3705a29c7628916796976d4b129; ?>
<?php unset($__attributesOriginale483f3705a29c7628916796976d4b129); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale483f3705a29c7628916796976d4b129)): ?>
<?php $component = $__componentOriginale483f3705a29c7628916796976d4b129; ?>
<?php unset($__componentOriginale483f3705a29c7628916796976d4b129); ?>
<?php endif; ?>
</head>

<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
    <nav class="sb-topnav navbar navbar-white bg-white">
        <a class="navbar-brand ps-3" href="<?php echo e(url('/')); ?>">
            <img class="navbar-logo" src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
        </a>
        <div class="dropdown">
            <span class="navbar-profile" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <h2><i class="fa-solid fa-circle-user"></i></h2>
            </span>

            <ul class="dropdown-menu end-right">
                <li><a class="dropdown-item" href="#">Hello, <?php echo 'chris_wong_123' ?></a></li>
                <li><a class="dropdown-item" href="#"><i class="fa-solid fa-language"></i>中文</a></li>
                <li><a class="dropdown-item" href="#"><i class="fa-solid fa-arrow-right-from-bracket"></i>Sign out</a></li>
            </ul>
        </div>
    </nav>
</div><?php /**PATH D:\working\Freelancer\20240606_Schoolmangement_laravel11_Natarajan\updateDigitalschool\resources\views/top-nav.blade.php ENDPATH**/ ?>