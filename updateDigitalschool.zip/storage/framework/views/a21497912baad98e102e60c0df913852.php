<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>School Management</title>
         <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss','resources/sass/base.scss','resources/sass/common.scss','resources/sass/leftmenu.scss','resources/sass/home.scss','resources/sass/footer.scss', 'resources/js/app.js']); ?>
        
           <style>
            .nav-link:not([href="index.html"]) {
                display: none;
            }
            .nav-link[href="index.html"]{
                background-color: white;
                color: #007A9C;
            }
            .nav-link[href="index.html"] .left-menu-text{
                color: #007A9C;
            }
        </style>
         <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-white bg-white">
            <a class="navbar-brand ps-3" href="index.html">
                <img class="navbar_logo" src="assets/img/logo.png" alt="Logo" >
            </a>
            <a class="navbar-profile" href="#"><h2><i class="fa-solid fa-circle-user"></i></h2></a>           
        </nav>
        
        <div id="banner" class="d-flex justify-content-center position-relative image-container">
            <div class="overlay-text">
                <p class="text-white fs-3 fw-light font-family-Inter  m-0 px-3 py-2">Welcome to English <br/></p>
                <p class="text-white fs-6 fw-normal font-family-Inter  m-0 px-3 py-2">Explore, discover, and grow together with our tailored resources. Let's make learning fun!<br/></p>
            </div>
        </div>
        
        <div class="main-content">
            <div id="layoutSidenav">
                <div id="layoutSidenav_nav">
                    <nav class="sb-sidenav accordion sb-sidenav-white" id="sidenavAccordion">
                        <div class="sb-sidenav-menu">
                            <div class="card mx-3 sidebar-card">
                                <div class="nav p-3">
                                    <a class="nav-link br-10 mb-3" href="index.html">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-house"></i></div>
                                        <label class="left-menu-text">My Home</label>
                                    </a>
                                    <a class="nav-link br-10 mb-3" href="schoolManagement.html">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-book"></i></div>
                                        <label class="left-menu-text">School Management</label>
                                    </a>
                                    <a class="nav-link br-10 mb-5" href="setting.html">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div>
                                        <label class="left-menu-text">My Settings</label>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
                <div id="layoutSidenav_content">
                    <div class="card main-card">
                        <main>
                            <div class="container-fluid px-4">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="mt-4 order-1 FYI-title">My Home</h3>
                                    <div class="mt-4 order-2">
                                        <button type="button" class="btn btn-dark btn-text-download">How to use</button>
                                        <button type="button" class="btn btn-dark btn-text-download">Download Apps</button>
                                    </div>
                                </div>
                                <div>
                                    <div class="row pt-4">
                                        <div class="info-panel">
                                            <p class="m-3 " >You haven't finish the setup of newsletter, go <a class="link-blue" href="#">setup now.</a><a class="link-blue link-setup-later" href="#">Setup Later</a></p>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-xl-3 col-md-6">
                                            <p class="mt-3 mb-0">Identity</p>
                                            <div class="card text-white mb-4 border-none">
                                                <select class="form-select" id="teacher_option" >
                                                    <option selected value="Teacher">Teacher</option>
                                                    <option value="Maths Teacher">Maths Teacher</option>
                                                    <option value="Physics Teacher">Physics Teacher</option>
                                                    <option value="Computer Teacher">Computer Teacher</option>
                                                    <option value="English Teacher">English Teacher</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-md-6">
                                            <p class="mt-3 mb-0">School Year</p>
                                            <div class="card text-white mb-4 border-none">
                                                <select class="form-select" id="years_option">
                                                    <option selected>2023-2024</option>
                                                    <option value="option1">2022-2023</option>
                                                    <option value="option2">2021-2022</option>
                                                    <option value="option3">2020-2021</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row home_main ">
                                        <label class="divider" for="platform"><i class="fa-solid fa-rectangle-list label_i" ></i>Platform</label>
                                        <div class="row" id="platform">
                                            <div class="col-xl-4">
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src="assets/img/completeExam.png" /></div>
                                                    <div class="col-xl-8"><span>Complete Exam Practice <br> (Third edition) <br>PEC</span></div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src="assets/img/JsPEC.png" /></div>
                                                    <div class="col-xl-8"><span>Junior Secondary PEC <br> -Longman English <br>Edge/ Spark!</span></div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src="assets/img/Edge.png" /></div>
                                                    <div class="col-xl-8"><span>>Longman English Edge <br> (2nd Edition) PEC</span</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" id="platform">
                                            <div class="col-xl-4">
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src="assets/img/Longman.png" /></div>
                                                    <div class="col-xl-8"><span>Primary Longman Elect <br> (2nd Edition) PEC</span></div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src="assets/img/completeExam.png" /></div>
                                                    <div class="col-xl-8"><span>Complete Exam <br> Practice (Third edition) <br>PEC</span></div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4">
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src="assets/img/Pec.png" /></div>
                                                    <div class="col-xl-8"><span>iLesson Sec. Jr. English</span></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row home_main home_main_text">
                                        <label class="divider"><i class="fa-regular fa-file-lines label_i"></i>Teacher Resource</label>
                                        <div class="col-xl-4">
                                            <div class="row">
                                                <div class="col-xl-4 platform-image"><img src="assets/img/completeExam.png" /></div>
                                                <div class="col-xl-8"><span>Complete Exam Practice <br> (Third edition) <br>PEC</span></div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4">
                                            <div class="row">
                                                <div class="col-xl-4 platform-image"><img src="assets/img/Edge.png" /></div>
                                                <div class="col-xl-8"><span>Junior Secondary PEC <br> -Longman English <br>Edge/ Spark!</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </main>
                    </div>
                </div>
            </div>
            <nav class="footer">
                <div class="container-fluid">
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                </div>
            </nav>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\my-pearson-digital-v2\resources\views/test.blade.php ENDPATH**/ ?>