<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <?php if (isset($component)) { $__componentOriginal9b26c56ae0f948ae51e873b8663e9f53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-base','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53)): ?>
<?php $attributes = $__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53; ?>
<?php unset($__attributesOriginal9b26c56ae0f948ae51e873b8663e9f53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b26c56ae0f948ae51e873b8663e9f53)): ?>
<?php $component = $__componentOriginal9b26c56ae0f948ae51e873b8663e9f53; ?>
<?php unset($__componentOriginal9b26c56ae0f948ae51e873b8663e9f53); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginale483f3705a29c7628916796976d4b129 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale483f3705a29c7628916796976d4b129 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-vite','data' => ['importCssPath' => 'resources/css/Home.css']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-vite'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['importCssPath' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('resources/css/Home.css')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale483f3705a29c7628916796976d4b129)): ?>
<?php $attributes = $__attributesOriginale483f3705a29c7628916796976d4b129; ?>
<?php unset($__attributesOriginale483f3705a29c7628916796976d4b129); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale483f3705a29c7628916796976d4b129)): ?>
<?php $component = $__componentOriginale483f3705a29c7628916796976d4b129; ?>
<?php unset($__componentOriginale483f3705a29c7628916796976d4b129); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal0cbc308b3ff0276709ae76208f29eb48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0cbc308b3ff0276709ae76208f29eb48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-style','data' => ['linkTo' => url('/')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head-style'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['linkTo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(url('/'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0cbc308b3ff0276709ae76208f29eb48)): ?>
<?php $attributes = $__attributesOriginal0cbc308b3ff0276709ae76208f29eb48; ?>
<?php unset($__attributesOriginal0cbc308b3ff0276709ae76208f29eb48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0cbc308b3ff0276709ae76208f29eb48)): ?>
<?php $component = $__componentOriginal0cbc308b3ff0276709ae76208f29eb48; ?>
<?php unset($__componentOriginal0cbc308b3ff0276709ae76208f29eb48); ?>
<?php endif; ?>
        <meta name="app-url" content="<?php echo e(url('/')); ?>">
        <meta name="icon-base-url" content="<?php echo e(config("leap.application.icon.basePath")); ?>">

    </head>
    <body class="sb-nav-fixed">
        <!-- Top nav -->
        <?php if (isset($component)) { $__componentOriginal567aee8eba9946a4094af278d0455b7e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal567aee8eba9946a4094af278d0455b7e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.top-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('top-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal567aee8eba9946a4094af278d0455b7e)): ?>
<?php $attributes = $__attributesOriginal567aee8eba9946a4094af278d0455b7e; ?>
<?php unset($__attributesOriginal567aee8eba9946a4094af278d0455b7e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal567aee8eba9946a4094af278d0455b7e)): ?>
<?php $component = $__componentOriginal567aee8eba9946a4094af278d0455b7e; ?>
<?php unset($__componentOriginal567aee8eba9946a4094af278d0455b7e); ?>
<?php endif; ?>

        <!-- Banner Image -->
        <?php if (isset($component)) { $__componentOriginal0f6ef56e3d0ce29407bf4273bf32e60d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f6ef56e3d0ce29407bf4273bf32e60d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.body-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('body-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f6ef56e3d0ce29407bf4273bf32e60d)): ?>
<?php $attributes = $__attributesOriginal0f6ef56e3d0ce29407bf4273bf32e60d; ?>
<?php unset($__attributesOriginal0f6ef56e3d0ce29407bf4273bf32e60d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f6ef56e3d0ce29407bf4273bf32e60d)): ?>
<?php $component = $__componentOriginal0f6ef56e3d0ce29407bf4273bf32e60d; ?>
<?php unset($__componentOriginal0f6ef56e3d0ce29407bf4273bf32e60d); ?>
<?php endif; ?>

        <!-- Main Layout -->
        <div id="layoutSidenav">

            <?php if (isset($component)) { $__componentOriginald5b0d6cc9367610ffc331bacb8d5777a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.side-nav-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('side-nav-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a)): ?>
<?php $attributes = $__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a; ?>
<?php unset($__attributesOriginald5b0d6cc9367610ffc331bacb8d5777a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5b0d6cc9367610ffc331bacb8d5777a)): ?>
<?php $component = $__componentOriginald5b0d6cc9367610ffc331bacb8d5777a; ?>
<?php unset($__componentOriginald5b0d6cc9367610ffc331bacb8d5777a); ?>
<?php endif; ?>

            <div id="layoutSidenav_content">
                <div class="card main-card">
                    <main>
                        <div class="container-fluid px-4">

                            <?php if (isset($component)) { $__componentOriginal6fe31aef5e73f985aa6a660584b796ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fe31aef5e73f985aa6a660584b796ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-card-top','data' => ['title' => 'My Home']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-card-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('My Home')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fe31aef5e73f985aa6a660584b796ac)): ?>
<?php $attributes = $__attributesOriginal6fe31aef5e73f985aa6a660584b796ac; ?>
<?php unset($__attributesOriginal6fe31aef5e73f985aa6a660584b796ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fe31aef5e73f985aa6a660584b796ac)): ?>
<?php $component = $__componentOriginal6fe31aef5e73f985aa6a660584b796ac; ?>
<?php unset($__componentOriginal6fe31aef5e73f985aa6a660584b796ac); ?>
<?php endif; ?>

                            <div class="col">
                                <div class="row mt-4">

                                    <?php if (isset($component)) { $__componentOriginala5681a2b31b7af68eb08766f178bd8e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala5681a2b31b7af68eb08766f178bd8e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-card-alert','data' => ['alertMessage' => 'You have not finish the setup of newsletter, go ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-card-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['alertMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('You have not finish the setup of newsletter, go ')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala5681a2b31b7af68eb08766f178bd8e7)): ?>
<?php $attributes = $__attributesOriginala5681a2b31b7af68eb08766f178bd8e7; ?>
<?php unset($__attributesOriginala5681a2b31b7af68eb08766f178bd8e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala5681a2b31b7af68eb08766f178bd8e7)): ?>
<?php $component = $__componentOriginala5681a2b31b7af68eb08766f178bd8e7; ?>
<?php unset($__componentOriginala5681a2b31b7af68eb08766f178bd8e7); ?>
<?php endif; ?>

                                </div>
                                <div class="row mt-2">
                                    <div class="col-xl-3 col-md-6">
                                        <p class="mt-3 mb-0">Identity</p>
                                        <div class="card mb-4 border-none">
                                            <select class="form-select" id="role_option">

                                                <?php $__currentLoopData = $crossRoleSchoolYearInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleId => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($roleId); ?>"
                                                 <?php echo e($selectedRoleId == $roleId ? 'selected' : ''); ?>

                                                >
                                                    <?php echo e($role['name']); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <p class="mt-3 mb-0">School Year</p>
                                        <div class="card mb-4 border-none">
                                            <select class="form-select" id="school_year_option">

                                                <?php $__currentLoopData = $crossRoleSchoolYearInfo[$selectedRoleId]['schoolYears']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schoolYearId => $schoolYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($schoolYearId); ?>"
                                                <?php echo e($selectSchoolYearId == $schoolYearId ? 'selected' : ''); ?>

                                                >
                                                    <?php echo e($schoolYear['SchoolYear']); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="platform-section">
                                    <label class="divider sub-title"><i class="fa-solid fa-rectangle-list mr-2" ></i>Platform</label>
                                    <div class="row application-content">
                                        <?php $__currentLoopData = $applicationsInfo['platform']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-4 application-wrapper">
                                            <a href=<?php echo e($application["TeacherURL"]); ?>>
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src=<?php echo e(config("leap.application.icon.basePath")."/".$application["TeacherIcon"]); ?> /></div>
                                                    <div class="col-xl-8"><span><?php echo e($application["Name"]); ?></span></div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="row mb-5" id="common-section">
                                    <label class="divider sub-title"><i class="fa-regular fa-file-lines mr-2"></i>Teacher Resource</label>
                                    <div class="row application-content">
                                        <?php $__currentLoopData = $applicationsInfo['common']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-4 application-wrapper">
                                            <a href=<?php echo e($application["TeacherURL"]); ?>>
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src=<?php echo e(config("leap.application.icon.basePath")."/".$application["TeacherIcon"]); ?> /></div>
                                                    <div class="col-xl-8"><span><?php echo e($application["Name"]); ?></span></div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="row mb-5" id="ebook-section">
                                    <label class="divider sub-title"><i class="fa-regular fa-file-lines mr-2"></i>EBook</label>
                                    <div class="row application-content">
                                        <?php $__currentLoopData = $applicationsInfo['ebook']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-4 application-wrapper">
                                            <a href=<?php echo e($application["TeacherURL"]); ?>>
                                                <div class="row">
                                                    <div class="col-xl-4 platform-image"><img src=<?php echo e(config("leap.application.icon.basePath")."/".$application["TeacherIcon"]); ?> /></div>
                                                    <div class="col-xl-8"><span><?php echo e($application["Name"]); ?></span></div>
                                                </div>
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>

        </div>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>

        <script type="module">
            $(document).ready(function() {
                $('#role_option').on('change', function(){
                    getApplications();
                });

                $('#school_year_option').on('change', function(){
                    getApplications();
                });

                function applicationUITemplate(application){
                    let iconBaseUrl = $('meta[name=icon-base-url]').attr("content");
                    let html = "";
                    html += `<div class="col-4 application-wrapper">`;
                    html += `<a href="${application["TeacherURL"]}">`;
                    html += `<div class="row">`;
                    html += `<div class="col-xl-4 platform-image"><img src="${iconBaseUrl}/${application["TeacherIcon"]}" /></div>`;
                    html += `<div class="col-xl-8"><span>${ application["Name"] }</span></div></div></a></div>`;

                    return html;
                }

                function getApplications(){
                    let roleId = $('#role_option > option:selected').val();
                    let schoolYearId = $('#school_year_option > option:selected').val();
                    let url = $('meta[name=app-url]').attr("content") + "/applications?roleId="+roleId+"&schoolYearId="+schoolYearId;

                    $.ajax({
                        url: url,
                        type: "GET",
                        success: function(response) {
                            console.log(response);

                            $("#platform-section .application-content").empty();
                            $("#common-section .application-content").empty();
                            $("#ebook-section .application-content").empty();

                            response['platform'].forEach(application => {
                                $("#platform-section .application-content").append(applicationUITemplate(application));
                            });

                            response['common'].forEach(application => {
                                $("#common-section .application-content").append(applicationUITemplate(application));
                            });

                            response['ebook'].forEach(application => {
                                $("#ebook-section .application-content").append(applicationUITemplate(application));
                            });
                        },
                        error: function(response) {
                            console.log(response.responseJSON)
                        }
                    });
                }
            });
        </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\my-pearson-digital-v2\resources\views/home.blade.php ENDPATH**/ ?>