<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>School Management</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss','resources/sass/base.scss','resources/sass/common.scss','resources/sass/leftmenu.scss','resources/sass/settings.scss','resources/sass/footer.scss', 'resources/js/app.js']); ?>
        
     
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <style>
            .nav-link:not([href="setting.html"]) {
                display: none;
            }
            .nav-link[href="setting.html"]{
                background-color: white;
                color: #007A9C;
            }
            .nav-link[href="setting.html"] .left-menu-text{
                color: #007A9C;
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-white bg-white">
            <a class="navbar-brand ps-3" href="index.html">
                <img class="navbar_logo" src="assets/img/logo.png" alt="Logo">
            </a>
            <a class="navbar-profile" href="#"><h2><i class="fa-solid fa-circle-user"></i></h2></a>          
        </nav>
        
        <div id="banner" class="d-flex justify-content-center position-relative image-container">
            <div class="overlay-text">
                <p class="text-white fs-3 fw-light font-family-Inter  m-0 px-3 py-2">Welcome to English <br/></p>
                <p class="text-white fs-6 fw-normal font-family-Inter  m-0 px-3 py-2">Explore, discover, and grow together with our tailored resources. Let's make learning fun!<br/></p>
            </div>
        </div>
        <div class="main-content">
            <div id="layoutSidenav">
                <div id="layoutSidenav_nav">
                    <nav class="sb-sidenav accordion sb-sidenav-white" id="sidenavAccordion">
                        <div class="sb-sidenav-menu">
                            <div class="card mx-3 sidebar-card">
                                <div class="nav p-3">
                                    <a class="nav-link br-10 mb-3" href="index.html">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-house"></i></div>
                                        <label class="left-menu-text">My Home</label>
                                    </a>
                                    <a class="nav-link br-10 mb-3" href="schoolManagement.html">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-book"></i></div>
                                        <label class="left-menu-text">School Management</label>
                                    </a>
                                    <a class="nav-link br-10 mb-5" href="setting.html">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div>
                                        <label class="left-menu-text">My Settings</label>
                                    </a>
                                </div>
                            </div>
                            
                        </div>
                    </nav>
                </div>
                <div id="layoutSidenav_content">
                    <div class="card main-card">
                        <main>
                            <div class="container-fluid px-4">
                                <!-- Page Title -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="mt-4 order-1 FYI-title">My Settings</h3>
                                </div>
                                <div>
                                    <div class="row mt-4">
                                        <label class="divider"><i class="fa-solid fa-user"></i> My Profile </label>
                                        <div class="col-xl-3">
                                            <div class="card  text-black setting-cards" id="setting_profile_edit">
                                                <div class="card-body setting-cards-body">
                                                    <img src="assets/img/icons/manage_accounts.png" />
                                                </div>
                                            </div>
                                            <p>Edit My Profile</p>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="card text-black setting-cards" id="setting_profile_promotion">
                                                <div class="card-body setting-cards-body">
                                                    <img src="assets/img/icons/email.png"  />
                                                </div>
                                            </div>
                                            <p>Promotion and Newsletter</p>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="card text-black setting-cards" id="setting_profile_addin">
                                                <div class="card-body setting-cards-body">
                                                    <img src="assets/img/icons/qr_code.png" />
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Add Pin</p>
                                                <p class="order-2">
                                                    <a><i class="fa-solid fa-up-right-from-square"></i></a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row my-4">
                                        <label class="divider"><i class="fa-solid fa-shield-halved"></i> Security </label>
                                        <div class="col-xl-3">
                                            <div class="card text-black setting-cards" id="setting_security_password">
                                                <div class="card-body setting-cards-body">
                                                    <img src="assets/img/icons/password.png" />
                                                </div>
                                            </div>
                                            <p>Change Password</p>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="card text-black setting-cards" id="setting_security_email">
                                                <div class="card-body setting-cards-body">
                                                    <img src="assets/img/icons/verified_user.png" />
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <p class="order-1">Email or Mobile Verification</p>
                                                <p class="order-2">
                                                    <a><i class="fa-solid fa-up-right-from-square"></i></a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </main>
                    </div>
                    
                </div>
            </div>
            <!-- Footer -->
            <nav class="footer">
                <div class="container-fluid">
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                  <a class="footer_item" href="#"><span>Fixed bottom</span></a>
                </div>
            </nav>
        </div>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\my-pearson-digital-v2\resources\views/settings.blade.php ENDPATH**/ ?>