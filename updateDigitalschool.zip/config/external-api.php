<?php

return [
    'base_url' => 'https://leap.beta.ilongman.com',
    'endpoint_path' => 'acs-web/App/ACSGateway.do',
];
