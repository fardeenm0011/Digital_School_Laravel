<?php

return [
    'host' => [
        'url' => 'https://iam-stage.pearson.com/',
    ],
    'verify_ssotoken' => [
        'url' => 'auth/json/realms/root/realms/pearson/sessions/?_action=getSessionInfo&tokenId={SSOToken}',
    ],
    'b2cSchoolDetail' => ['SchoolCode' => '3999999', 'ChiName' => 'B2C Dummy School', 'Name' => 'B2C Dummy School'],
    'leap' => [
        'SchoolTypeMapping' => ['1' => 'P', '2' => 'S', '3' => 'DEMO', '4' => 'PRE'],
        'CurrentSchoolYear' => '19',
        'Host' => ['url' => 'http://leap.beta.ilongman.com'],
        'getAccessRights' => ['getByUser' => '/acs-web/App/ACSGateway.do?method=getAccessRights&asMethod=getByUser&loginId=${username}&schoolYearId=${schoolYearId}',
            'getDelimiterAccessRightsWithMultipleSVCodes' => '/acs-web/App/ACSGateway.do?method=getAccessRights&asMethod=getDelimiterAccessRightsWithMultipleSVCodes&loginId=${username}&serviceCodes=${servicecodelist}',
            'getDelimiterApplicationIds' => '/acs-web/App/ACSGateway.do?method=getAccessRights&asMethod=getDelimiterApplicationIds&loginId=${username}&applicationIds=${servicecodelist}',
        ],
        'getProfile' => ['get' => '/acs-web/App/ACSGateway.do?method=getProfile&asMethod=get&loginId=${username}',
            'getSimple' => '/acs-web/App/ACSGateway.do?method=getProfile&asMethod=getSimple&loginId=${username}',
            'getRole' => '/acs-web/App/ACSGateway.do?method=getProfile&asMethod=getRole&loginId=${username}',
            'getYearInfo' => '/acs-web/App/ACSGateway.do?method=getProfile&asMethod=getYearInfo&loginId=${username}',
        ],
        'getSchool' => ['getAdoptionSchool' => '/acs-web/App/ACSGateway.do?method=getSchools&asMethod=getByServiceCode&serviceCode=${serviceCode}',
            'getByUser' => '/acs-web/App/ACSGateway.do?method=getSchools&asMethod=getByUser&loginId=${username}&schoolYearId=${schoolYearId}',
            'getBySchoolCode' => '/acs-web/App/ACSGateway.do?method=getSchools&asMethod=get&schoolCode=${schoolCode}',
            'getYearInfo' => '/acs-web/App/ACSGateway.do?method=getProfile&asMethod=getYearInfo&loginId=${username}'],
        'getUser' => ['getSchoolAllTeachersProfile' => '/acs-web/App/ACSGateway.do?method=getUsers&asMethod=getSchoolAllTeachersProfile&schoolCode=${schoolCode}&schoolYearId=${schoolYearId}',
        ],
        'getStudyGroup' => ['getStudyGroups' => '/acs-web/App/ACSGateway.do?method=getStudyGroups&asMethod=getBySchool&schoolCode=${schoolCode}&schoolYearId=${schoolYearId}',
        ],
        'getBookSeries' => ['getBookSeries' => '/acs-web/App/ACSGateway.do?method=getStaticData&asMethod=getBookSeries',
        ],
        'getUsers' => ['getUsersByStudyGroup' => '/acs-web/App/ACSGateway.do?method=getUsers&asMethod=getUsersByGroup&studyGroupId=${studyGroupId}',
        ],
        'login' => [
            'simpleLogin' => '/acs-web/App/ACSGateway.do?method=login&asMethod=simpleLogin&loginId=${username}&password=${password}',
        ],
    ],
    'externalApps' => [
        'EBOOK4' => ['web' => 'https://ebook4.ilongman.com/sso.saml.php',
            'iOS' => 'ebook4://',
            'Android' => 'com.pearson.ebook4',
            // DEV
            'hawkId' => '98e8cc32-16a3-42d5-a79d-34d3374f1898',
            'hawkKey' => 'bd6dfc17-dbbb-4bfd-a73f-ebfa150074f8',
            // PROD
            //'hawkId'=>'415c6873-ebb5-4e53-b4ac-f5396bf492be',
            //'hawkKey' => 'cc210a97-93d3-474e-ab0f-2c550934a146',
        ],
    ],
];
