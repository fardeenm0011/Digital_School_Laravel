<?php

return [
    'IESurl' => 'https://iesregister.beta4.ilongman.com/ieslogin.php',
    'IESlang' => 'en-US',
    'IESBACKURL' => 'https:%2F%2Fiesregister.beta4.ilongman.com%2Fieschecksession.php',
    'IESlang2' => 'en-US',
    'validate_sso_url' => 'https://iam-stage.pearson.com/auth/oauth2/tokeninfo?access_token=',
    'Add_Pin' => 'https://iesregister.beta4.ilongman.com/pin.php',
];
