<?php

return [
    'leap_url' => env('LEAP_URL', 'https://leap.beta.ilongman.com'),
    'application' => [
        'icon' => [
            'basePath' => env('LEAP_URL', 'https://leap.beta.ilongman.com').'/acs-web/images/product',
        ],
    ],
];
